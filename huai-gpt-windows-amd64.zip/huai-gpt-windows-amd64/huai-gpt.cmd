@echo off
setlocal
set APP_DIR=%~dp0
set CONF=%APP_DIR%config.json

if "%1"=="" goto help
if /I "%1"=="once" (
  "%APP_DIR%huai-gpt.exe" --config "%CONF%" --once
  exit /b %errorlevel%
)
if /I "%1"=="run" (
  if "%2"=="" (
    "%APP_DIR%huai-gpt.exe" --config "%CONF%"
  ) else (
    "%APP_DIR%huai-gpt.exe" --config "%CONF%" --concurrency %2
  )
  exit /b %errorlevel%
)
:help
echo Usage:
echo   huai-gpt.cmd once
echo   huai-gpt.cmd run [threads]
exit /b 1
